package com.Customer.orders.dto;

public class CustomerCrtDto {
	
	private String customerName;
	private String customerAddress;
	
	
	public CustomerCrtDto() {
		super();
	}
	public CustomerCrtDto(String customerName, String customerAddress) {
		super();
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	@Override
	public String toString() {
		return "CustomerCrtDto [customerName=" + customerName + ", customerAddress=" + customerAddress + "]";
	}
	

	
}
