package com.Customer.orders.dto;


public class OrderUpdateDto {
	
	private Long orderId;
	private int quantity;
	private Double totalOrderAmount;
	private Long customerId;
	private Long mobileId;
	public OrderUpdateDto(Long orderId, int quantity, Double totalOrderAmount, Long customerId, Long mobileId) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.totalOrderAmount = totalOrderAmount;
		this.customerId = customerId;
		this.mobileId = mobileId;
	}
	public OrderUpdateDto() {
		super();
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Double getTotalOrderAmount() {
		return totalOrderAmount;
	}
	public void setTotalOrderAmount(Double totalOrderAmount) {
		this.totalOrderAmount = totalOrderAmount;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getMobileId() {
		return mobileId;
	}
	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "OrderUpdateDto [orderId=" + orderId + ", quantity=" + quantity + ", totalOrderAmount="
				+ totalOrderAmount + ", customerId=" + customerId + ", mobileId=" + mobileId + "]";
	}
	

}
