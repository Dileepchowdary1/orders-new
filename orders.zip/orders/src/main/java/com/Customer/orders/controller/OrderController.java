package com.Customer.orders.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Customer.orders.dto.GetAllMobile;
import com.Customer.orders.dto.GetOrders;
import com.Customer.orders.dto.OrderCrtDto;
import com.Customer.orders.dto.OrderUpdateDto;
import com.Customer.orders.dto.ResponseDto;
import com.Customer.orders.service.OrderService;

@RestController
@RequestMapping("orders/")
public class OrderController {

	public static final Logger logger = LogManager.getLogger(OrderController.class);
	@Autowired
	OrderService orderService;

	@PostMapping(path = "submit", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> submitOrder(@RequestBody OrderCrtDto order) {
		ResponseDto response = null;
		try {
			Long orderId = orderService.submitOrder(order);
			if (orderId > 0) {
				response = new ResponseDto(orderId, "Submit Order Successfully");
				logger.info("{} <<:saveMobile:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(orderId, "Submit Order unSuccessfully");
				logger.info("{} <<:saveMobile:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error saving orders", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(path = "getallorders", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<GetOrders>> getAllOrders() {
		try {
			List<GetOrders> response = orderService.getAllOrders();
			logger.info("{} <<:getAllOrders:Response:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
		}
	}
	
	@PutMapping(path = "updateorders/{orderId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> updateMobile(@RequestBody OrderUpdateDto updateDto) {
		ResponseDto response = null;
		try {
			long id = orderService.updateOrders(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "Order update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Order update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@DeleteMapping(path = "deleteorders/{orderId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deleteOrders(@PathVariable("orderId") Long orderId) {
		ResponseDto response = null;
		try {
			long id = orderService.deleteOrdersById(orderId);
			if (id > 0) {
				response = new ResponseDto(id, "Order deleted Successfully");
				logger.info("{} <<:deleteOrders:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Order fail to delete");
				logger.info("{} <<:deleteOrders:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@GetMapping(path = "/getById/{orderId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<GetOrders> getOrdersById(@PathVariable("orderId") Long orderId) {
        try {
        	GetOrders response = orderService.getOrdersById(orderId);
            if (response != null) {
                logger.info(">>getOrdersById:[{}]", response);
                return ResponseEntity.status(HttpStatus.OK).body(response);
            } else {
                logger.info("{} <<:getOrdersById:Response:{}", response);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
