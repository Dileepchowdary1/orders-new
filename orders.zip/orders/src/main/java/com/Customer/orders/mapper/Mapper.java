package com.Customer.orders.mapper;

import java.util.List;

import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.Customer.orders.dto.CustomerUpdateDto;
import com.Customer.orders.dto.GetAllCustomers;
import com.Customer.orders.dto.GetAllMobile;
import com.Customer.orders.dto.GetOrders;
import com.Customer.orders.dto.MobileUpdateDto;
import com.Customer.orders.dto.OrderUpdateDto;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.Mobile;
import com.Customer.orders.entity.PurchaseOrder;



@org.mapstruct.Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "String")
public interface Mapper {
	
	Mapper INSTANCE = Mappers.getMapper(Mapper.class);

	Customers updateDtoToCustomer(CustomerUpdateDto dto);
	
	 List<GetAllCustomers> getAllCustomersToEntity(List<Customers> customers);

	List<GetAllMobile> getAllMobilesToEntity(List<Mobile> mobile);

	Mobile updateDtoToMobile(MobileUpdateDto updateDto);
	
	GetAllMobile getMobilesById(Mobile mobiles);

	List<GetOrders> getAllOrdersToEntity(List<PurchaseOrder> orders);

	PurchaseOrder updateDtoToOrder(OrderUpdateDto updateDto);
	

}
