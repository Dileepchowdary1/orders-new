package com.Customer.orders.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "mobile")
public class Mobile {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="mobile_Id")
	private Long mobileId;
	
	@Column(name="mobile_Name")
	private String mobileName;
	
	@Column(name="mobile_Price")
	private Double mobilePrice;
	
	@Column(name = "stock_quantity")
    private Integer stockQuantity;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "customer_id")
    private Customers customer;
	
//	@OneToMany(mappedBy = "mobile", cascade = CascadeType.ALL)
	 @OneToMany(mappedBy = "mobile", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<PurchaseOrder> purchaseOrders;

	
	public Mobile() {
		super();
	}


	public Mobile(Long mobileId, String mobileName, Double mobilePrice,Integer stockQuantity, Customers customer,
			List<PurchaseOrder> purchaseOrders) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
		this.customer = customer;
		this.purchaseOrders = purchaseOrders;
		this.stockQuantity=stockQuantity;
	}

	public List<PurchaseOrder> getPurchaseOrders() {
		return purchaseOrders;
	}

	public void setPurchaseOrders(List<PurchaseOrder> purchaseOrders) {
		this.purchaseOrders = purchaseOrders;
	}

	public Long getMobileId() {
		return mobileId;
	}

	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public Double getMobilePrice() {
		return mobilePrice;
	}

	public void setMobilePrice(Double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customer) {
		this.customer = customer;
	}

	
	public Integer getStockQuantity() {
		return stockQuantity;
	}


	public void setStockQuantity(Integer stockQuantity) {
		this.stockQuantity = stockQuantity;
	}


	 @Override
	    public String toString() {
	        return "Mobile{" +
	                "mobileId=" + mobileId +
	                ", mobileName='" + mobileName + '\'' +
	                ", mobilePrice=" + mobilePrice +
	                ", stockQuantity=" + stockQuantity +
	                ", purchaseOrders=" + purchaseOrders +
	                '}';
	    }

}
