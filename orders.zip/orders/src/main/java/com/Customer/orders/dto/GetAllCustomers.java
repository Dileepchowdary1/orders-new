
package com.Customer.orders.dto;

	public class GetAllCustomers {
		private Long customerId;
		private String customerName;
		private String customerAddress;
		private int customerCreditScore;
		
		public GetAllCustomers() {
		}
		public GetAllCustomers(Long customerId, String customerName, String customerAddress,int customerCreditScore) {
			super();
			this.customerId = customerId;
			this.customerName = customerName;
			this.customerAddress = customerAddress;
			this.customerCreditScore=customerCreditScore;
			
		}
		
		
		public Long getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public String getCustomerAddress() {
			return customerAddress;
		}
		public void setCustomerAddress(String customerAddress) {
			this.customerAddress = customerAddress;
		}
		public int getCustomerCreditScore() {
			return customerCreditScore;
		}
		public void setCustomerCreditScore(int customerCreditScore) {
			this.customerCreditScore = customerCreditScore;
		}
		@Override
		public String toString() {
			return "GetAllCustomers [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
					+ customerAddress + ", customerCreditScore=" + customerCreditScore + "]";
		}

	}


