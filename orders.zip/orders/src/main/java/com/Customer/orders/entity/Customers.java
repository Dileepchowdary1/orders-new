package com.Customer.orders.entity;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customers_orders")
public class Customers{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="customer_Id")
	private Long customerId;
	
	@Column(name = "customer_Name")
	private String customerName;
	
	@Column(name = "customer_Address")
	private String customerAddress;
	
	@Column(name = "customer_CreditScore")
	private int customerCreditScore;
	
//	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	 @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Mobile> mobiles;
	
//	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	 @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<PurchaseOrder> purchaseOrders;

	
	public Customers() {
		super();
	}


	public Customers(Long customerId, String customerName, String customerAddress, int customerCreditScore,
			List<Mobile> mobiles, List<PurchaseOrder> purchaseOrders) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerCreditScore = customerCreditScore;
		this.mobiles = mobiles;
		this.purchaseOrders = purchaseOrders;
	}


	public List<PurchaseOrder> getPurchaseOrders() {
		return purchaseOrders;
	}


	public void setPurchaseOrders(List<PurchaseOrder> purchaseOrders) {
		this.purchaseOrders = purchaseOrders;
	}


	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getCustomerCreditScore() {
		return customerCreditScore;
	}

	public void setCustomerCreditScore(int customerCreditScore) {
		this.customerCreditScore = customerCreditScore;
	}

	public List<Mobile> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<Mobile> mobiles) {
		this.mobiles = mobiles;
	}


	 @Override
	    public String toString() {
	        return "Customers{" +
	                "customerId=" + customerId +
	                ", customerName='" + customerName + '\'' +
	                ", customerAddress='" + customerAddress + '\'' +
	                ", customerCreditScore=" + customerCreditScore +
	                ", mobiles=" + mobiles +
	                ", purchaseOrders=" + purchaseOrders +
	                '}';
	    }

}
