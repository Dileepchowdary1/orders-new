package com.Customer.orders.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Customer.orders.dto.CustomerUpdateDto;
import com.Customer.orders.entity.Customers;

@Repository
public interface CustomerRepo extends JpaRepository<Customers, Long> {


	@Query("select tbl from Customers tbl where tbl.customerId=:customerId")
	public CustomerUpdateDto updateCustomer(@Param("customerId") Long customerId);


	@Query("select tbl from Customers tbl where tbl.customerId=:customerId")
	public Customers getCustomersByCustomerId(@Param("customerId") Long customerId);
	
	@Query("select tbl from Customers tbl where tbl.customerCreditScore < 500")
    List<Customers> findNonEligibleCustomers();


	@Query("select c from Customers c where c.customerCreditScore BETWEEN 501 AND 750")
    List<Customers> findEligibleCustomers();


	@Query("select c from Customers c where c.customerCreditScore BETWEEN 451 AND 700")
    List<Customers> findCustomersWithMissedEligibility();
	
	


}
