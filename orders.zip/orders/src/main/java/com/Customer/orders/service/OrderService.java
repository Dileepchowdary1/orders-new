package com.Customer.orders.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Customer.orders.dto.GetAllMobile;
import com.Customer.orders.dto.GetOrders;
import com.Customer.orders.dto.OrderCrtDto;
import com.Customer.orders.dto.OrderUpdateDto;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.Mobile;
import com.Customer.orders.entity.PurchaseOrder;
import com.Customer.orders.mapper.Mapper;
import com.Customer.orders.repository.CustomerRepo;
import com.Customer.orders.repository.MobileRepo;
import com.Customer.orders.repository.OrderRepo;

@Service
public class OrderService {

	public static final Logger logger = LogManager.getLogger(OrderService.class);
	@Autowired
	private OrderRepo orderRepository;
	@Autowired
	MobileRepo mobileRepository;

	@Autowired
	CustomerRepo customerRepository;

	public Long submitOrder(OrderCrtDto orderRequestDto) {
		try {
			Customers customer = customerRepository.findById(orderRequestDto.getCustomerId())
					.orElseThrow(() -> new EntityNotFoundException(
							"Customer not found with ID: " + orderRequestDto.getCustomerId()));

			Mobile mobile = mobileRepository.findById(orderRequestDto.getMobileId()).orElseThrow(
					() -> new EntityNotFoundException("Mobile not found with ID: " + orderRequestDto.getMobileId()));

			PurchaseOrder order = new PurchaseOrder();
			order.setQuantity(orderRequestDto.getQuantity());
			order.setOrderDate(new Date());
			order.setTotalOrderAmount(mobile.getMobilePrice() * order.getQuantity());
			order.setCustomer(customer);
			order.setMobile(mobile);
			PurchaseOrder savedOrder = orderRepository.save(order);
			return savedOrder.getOrderId();
		} catch (EntityNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<GetOrders> getAllOrders() {
		try {
			List<Object[]> ordersWithCustomerAndMobile = orderRepository.findAllWithCustomerAndMobile();

			List<GetOrders> response = ordersWithCustomerAndMobile.stream().map(orderData -> {
				Long orderId = (Long) orderData[0];
				int quantity = (int) orderData[1];
				Date orderDate = (Date) orderData[2];
				Double totalOrderAmount = (Double) orderData[3];
				Long customerId = (Long) orderData[4];
				Long mobileId = (Long) orderData[5];
				return new GetOrders(orderId, quantity, orderDate, totalOrderAmount, customerId, mobileId);
			}).collect(Collectors.toList());
			logger.info("{} <<:getAllOrders:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public long updateOrders(OrderUpdateDto updateDto) {
		PurchaseOrder order = null;
		try {
			if (updateDto.getOrderId() != null && updateDto.getOrderId() > 0) {
				order = orderRepository.getOrdersByorderId(updateDto.getOrderId());
				if (order != null) {
					Customers customer = customerRepository.getOne(updateDto.getCustomerId());
					Mobile mobile=mobileRepository.getOne(updateDto.getMobileId());
					if (customer == null) {
	                    throw new EntityNotFoundException("Customer not found with ID: " + updateDto.getCustomerId());
	                }
					if (mobile == null) {
	                    throw new EntityNotFoundException("mobile not found with ID: " + updateDto.getMobileId());
	                }
					PurchaseOrder orderDto = Mapper.INSTANCE.updateDtoToOrder(updateDto);
					orderDto.setCustomer(customer);
					orderDto.setMobile(mobile);
					orderDto.setOrderDate(new Date());
					logger.info("{}<<:updateOrders:[{}]", orderDto);
					orderDto = orderRepository.saveAndFlush(orderDto);
					return orderDto.getOrderId();
				}
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public long deleteOrdersById(Long orderId) {
		try {
			logger.info("{} >> deleteMobileById:[{}],", orderId);
			orderRepository.deleteById(orderId);
			return orderId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}
	public GetOrders getOrdersById(Long orderId) {
		try {
			PurchaseOrder response = orderRepository.getOne(orderId);
			if (response!= null) {
				GetOrders dto = new GetOrders(response.getOrderId(), response.getQuantity(),
						response.getOrderDate(), response.getTotalOrderAmount(), response.getCustomer().getCustomerId(),
						response.getMobile().getMobileId());
				logger.info("{} <<:getOrdersById:Response:{}", dto);
				return dto;
			} else {
				logger.info("Order is null for orderId: {}", orderId);
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return null;
		}
	}

}
