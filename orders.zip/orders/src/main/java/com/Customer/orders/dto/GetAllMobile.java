package com.Customer.orders.dto;

public class GetAllMobile {
	
	private Long mobileId;
	private String mobileName;
	private Double mobilePrice;
	 private Long customerId;
	 private Integer stockQuantity;
	 
	public GetAllMobile() {
		super();
	}

	public GetAllMobile(Long mobileId, String mobileName, Double mobilePrice, Long customerId, Integer stockQuantity) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
		this.customerId = customerId;
		this.stockQuantity = stockQuantity;
	}

	public Long getMobileId() {
		return mobileId;
	}

	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public Double getMobilePrice() {
		return mobilePrice;
	}

	public void setMobilePrice(Double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Integer getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(Integer stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	@Override
	public String toString() {
		return "GetAllMobile [mobileId=" + mobileId + ", mobileName=" + mobileName + ", mobilePrice=" + mobilePrice
				+ ", customerId=" + customerId + ", stockQuantity=" + stockQuantity + "]";
	}

	 
}
