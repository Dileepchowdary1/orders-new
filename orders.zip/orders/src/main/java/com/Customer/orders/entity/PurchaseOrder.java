package com.Customer.orders.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="PurchaseOrder ")
public class PurchaseOrder  {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="order_Id")
	private Long orderId;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="order_Date")
	private Date orderDate;
	
	@Column(name = "total_Order_Amount")
    private Double totalOrderAmount;
	
	@ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "customer_Id", referencedColumnName = "customer_Id")
	private Customers customer;
	
	@ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "mobile_Id", referencedColumnName = "mobile_Id")
	private Mobile mobile;
	
	
	
	public PurchaseOrder() {
		super();
	}
	public PurchaseOrder(long orderId, int quantity, Customers customer, Mobile mobile, Date orderDate,Double totalOrderAmount) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.customer = customer;
		this.mobile = mobile;
		this.orderDate = orderDate;
		this.totalOrderAmount=totalOrderAmount;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	public Mobile getMobile() {
		return mobile;
	}
	public void setMobile(Mobile mobile) {
		this.mobile = mobile;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	public Double getTotalOrderAmount() {
		return totalOrderAmount;
	}
	public void setTotalOrderAmount(Double totalOrderAmount) {
		this.totalOrderAmount = totalOrderAmount;
	}
	@Override
    public String toString() {
        return "PurchaseOrder{" +
                "orderId=" + orderId +
                ", quantity=" + quantity +
                ", orderDate=" + orderDate +
                ", totalOrderAmount=" + totalOrderAmount +
                '}';
    }
	
}
