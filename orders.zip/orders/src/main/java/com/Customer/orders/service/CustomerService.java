package com.Customer.orders.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Customer.orders.dto.CustomerCrtDto;
import com.Customer.orders.dto.CustomerUpdateDto;
import com.Customer.orders.dto.GetAllCustomers;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.mapper.Mapper;
import com.Customer.orders.repository.CustomerRepo;

@Service
public class CustomerService {

	public static final Logger logger = LogManager.getLogger(CustomerService.class);

	@Autowired
	CustomerRepo customerRepository;

	public long saveCustomer(CustomerCrtDto dto) {
		try {
			logger.info("{} >> CreateCustomerDto:[{}],", dto);
			Customers customer = new Customers();
			customer.setCustomerName(dto.getCustomerName());
			customer.setCustomerAddress(dto.getCustomerAddress());
			customer.setCustomerCreditScore((int) (Math.random() * 800) + 1);
			Customers custResp = customerRepository.save(customer);
			logger.info("{} >> saveCustomer:[{}],", custResp);
			return custResp.getCustomerId();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public String fetchCustomerById(Long customerId) {
		try {
			logger.info("{} >> customerId:[{}],", customerId);
			Customers customer = customerRepository.findById(customerId).orElse(null);
			logger.info("{} >> customer:[{}],", customer);
			if (customer != null) {
				int creditScore = customer.getCustomerCreditScore();
				if (creditScore < 500) {
					return "Customer Not eligible for a loan";
				} else if (creditScore >= 501 && creditScore <= 750) {
					return "Customer Eligible for a phone less than $400";
				} else {
					return "Customer is eligible";
				}
			} else {
				return "Customer not found";
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e.getMessage());
			return "Error occurred";
		}
	}

	public long deleteCustomerById(Long customerId) {
		try {
			logger.info("{} >> deleteCustomerById:[{}],", customerId);
			customerRepository.deleteById(customerId);
			return customerId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}


	public long updateCustomers(CustomerUpdateDto updateDto) {
		Customers cust = null;
		try {
			if (updateDto.getCustomerId() != null && updateDto.getCustomerId() > 0) {
				cust = customerRepository.getCustomersByCustomerId(updateDto.getCustomerId());
			}
			if (cust != null) {
				Customers custDto = Mapper.INSTANCE.updateDtoToCustomer(updateDto);
				logger.info("{}<<:updateCustomers:[{}]", custDto);
				custDto = customerRepository.saveAndFlush(custDto);
				return custDto.getCustomerId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public List<GetAllCustomers> getAllCustomers() {
		try {
			List<Customers> allCustomers = customerRepository.findAll();
			List<GetAllCustomers> response = Mapper.INSTANCE.getAllCustomersToEntity(allCustomers);
			logger.info("{} <<:getAllCustomers:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}
	
}
