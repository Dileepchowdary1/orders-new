package com.Customer.orders.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Customer.orders.dto.GetAllMobile;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.Mobile;

@Repository
public interface MobileRepo extends JpaRepository<Mobile,Long>{

	
	@Query("select tbl from Mobile tbl where tbl.mobileId=:mobileId")
	public Mobile getMobilesBymobileId(@Param("mobileId") Long mobileId);
	
	@Query("select tbl.mobileId, tbl.mobileName,tbl.mobilePrice, tbl.customer.customerId, tbl.stockQuantity from Mobile tbl")
    List<Object[]> findAllMobiles();
    
//    Long mobileId, String mobileName, Double mobilePrice, Long customerId, Integer stockQuantity
}
