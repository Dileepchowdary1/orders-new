package com.Customer.orders.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="report")
public class Report {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="report_id")
    private Long reportId;

	@Column(name="date")
    private Date date;

	@Column(name="totalamount_noneligible")
    private double totalAmountNonEligible;

	@Column(name="totalrequests_eligiblecustomers")
    private long totalRequestsEligibleCustomers;

	public Report(Long reportId, Date date, double totalAmountNonEligible, long totalRequestsEligibleCustomers) {
		super();
		this.reportId = reportId;
		this.date = date;
		this.totalAmountNonEligible = totalAmountNonEligible;
		this.totalRequestsEligibleCustomers = totalRequestsEligibleCustomers;
	}

	public Report() {
		super();
	}

	public Long getReportId() {
		return reportId;
	}

	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getTotalAmountNonEligible() {
		return totalAmountNonEligible;
	}

	public void setTotalAmountNonEligible(double totalAmountNonEligible) {
		this.totalAmountNonEligible = totalAmountNonEligible;
	}

	public long getTotalRequestsEligibleCustomers() {
		return totalRequestsEligibleCustomers;
	}

	public void setTotalRequestsEligibleCustomers(long totalRequestsEligibleCustomers) {
		this.totalRequestsEligibleCustomers = totalRequestsEligibleCustomers;
	}

	@Override
	public String toString() {
		return "Report [reportId=" + reportId + ", date=" + date + ", totalAmountNonEligible=" + totalAmountNonEligible
				+ ", totalRequestsEligibleCustomers=" + totalRequestsEligibleCustomers + "]";
	}

	
}
