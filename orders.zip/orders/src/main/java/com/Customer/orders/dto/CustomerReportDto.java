package com.Customer.orders.dto;

public class CustomerReportDto {

	private Long customerId;
    private Double orderAmount;
    private boolean isEligible;
	public CustomerReportDto(Long customerId, Double orderAmount, boolean isEligible) {
		super();
		this.customerId = customerId;
		this.orderAmount = orderAmount;
		this.isEligible = isEligible;
	}
	public CustomerReportDto() {
		super();
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Double getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}
	public boolean isEligible() {
		return isEligible;
	}
	public void setEligible(boolean isEligible) {
		this.isEligible = isEligible;
	}
	@Override
	public String toString() {
		return "CustomerReportDto [customerId=" + customerId + ", orderAmount=" + orderAmount + ", isEligible="
				+ isEligible + "]";
	}
    
    
}
