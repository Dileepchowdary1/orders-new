package com.Customer.orders.controller;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.Report;
import com.Customer.orders.repository.CustomerRepo;
import com.Customer.orders.repository.OrderRepo;
import com.Customer.orders.repository.ReportRepo;

@Component
public class DailyReportJob {

	public static final Logger logger = LogManager.getLogger(DailyReportJob.class);

	@Autowired
	private CustomerRepo customerRepository;

	@Autowired
	private OrderRepo orderRepository;

	@Autowired
	ReportRepo reportRepository;

	@Scheduled(cron = "0 0 0 * * ?") // Run every day at midnight
	public void generateDailyReport() {
		try {
			List<Customers> nonEligibleCustomers = customerRepository.findNonEligibleCustomers();
			double totalAmountNonEligible = nonEligibleCustomers.stream().mapToDouble(customer -> {
				try {
					return orderRepository.getTotalAmountForCustomer(customer.getCustomerId());
				} catch (Exception e) {
					logger.error("Error calculating total amount for customer " + customer.getCustomerId(), e);
					return 0.0;
				}}).sum();
//			List<Customers> eligibleCustomers = customerRepository.findEligibleCustomers();
			long totalRequestsEligibleCustomers = orderRepository.countOrdersForEligibleCustomers();
			Report report = new Report();
			report.setDate(new Date());
			report.setTotalAmountNonEligible(totalAmountNonEligible);
			report.setTotalRequestsEligibleCustomers(totalRequestsEligibleCustomers);
			reportRepository.save(report);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error generating daily report", e);
		}
	}
}
