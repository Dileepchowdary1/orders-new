package com.Customer.orders.config;

import org.springframework.stereotype.Component;

import com.Customer.orders.dto.CustomerReportDto;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.PurchaseOrder;

@Component
public class CustomerRequestProcessor {
	
	 public CustomerReportDto process(PurchaseOrder purchaseOrder) {
	        CustomerReportDto report = new CustomerReportDto();
	        report.setCustomerId(purchaseOrder.getCustomer().getCustomerId());
	        report.setOrderAmount(purchaseOrder.getMobile().getMobilePrice());
	        report.setEligible(isCustomerEligible(purchaseOrder.getCustomer()));
	        return report;
	    }

	    private boolean isCustomerEligible(Customers customer) {
	        return customer.getCustomerCreditScore() >= 501 && customer.getCustomerCreditScore() <= 750;
	    }

}
