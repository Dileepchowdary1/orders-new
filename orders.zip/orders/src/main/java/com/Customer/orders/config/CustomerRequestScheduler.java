package com.Customer.orders.config;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.Customer.orders.dto.CustomerReportDto;
import com.Customer.orders.entity.PurchaseOrder;
import com.Customer.orders.repository.OrderRepo;

@Component
public class CustomerRequestScheduler {
	
	@Autowired
    private OrderRepo purchaseOrderRepository;

    @Autowired
    private CustomerRequestProcessor customerRequestProcessor;


    private int totalEligibleRequests = 0;
    private int totalNonEligibleRequests = 0;

    @Scheduled(cron = "0 0 1 * * ?") // Run every day at 1 AM
    public void generateCustomerPhoneRequestReport() {
        try {
            Date today = new Date();
            List<PurchaseOrder> purchaseOrders = purchaseOrderRepository.findByOrderDate(today);

            for (PurchaseOrder purchaseOrder : purchaseOrders) {
            	CustomerReportDto report = customerRequestProcessor.process(purchaseOrder);
                System.out.println(report);
                if (report.isEligible()) {
                    totalEligibleRequests++;
                } else {
                    totalNonEligibleRequests++;
                }
            }
            System.out.println("Total Eligible Requests: " + totalEligibleRequests);
            System.out.println("Total Non-Eligible Requests: " + totalNonEligibleRequests);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
