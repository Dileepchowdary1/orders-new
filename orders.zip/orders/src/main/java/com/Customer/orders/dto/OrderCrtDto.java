package com.Customer.orders.dto;

import java.util.Date;

public class OrderCrtDto {

	private int quantity; 
	private Long customerId;
	private Long mobileId;
	public OrderCrtDto() {
		super();
	}
	
	public OrderCrtDto(int quantity, Long customerId, Long mobileId) {
		super();
		this.quantity = quantity;
		this.customerId = customerId;
		this.mobileId = mobileId;
	}

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getMobileId() {
		return mobileId;
	}
	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}

	@Override
	public String toString() {
		return "OrderCrtDto [quantity=" + quantity + ", customerId=" + customerId + ", mobileId=" + mobileId + "]";
	}
	
}
