package com.Customer.orders.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Customer.orders.entity.PurchaseOrder;

@Repository
public interface OrderRepo extends JpaRepository<PurchaseOrder,Long>{

	List<PurchaseOrder> findByOrderDate(Date today);

	@Query("select tbl from PurchaseOrder tbl where tbl.orderId=:orderId")
	public PurchaseOrder getOrdersByorderId(@Param("orderId") Long orderId);

	@Query("select o.orderId, o.quantity, o.orderDate, o.totalOrderAmount, o.customer.customerId, o.mobile.mobileId from PurchaseOrder o")
    List<Object[]> findAllWithCustomerAndMobile();

	 @Query("select SUM(tbl.totalOrderAmount) from PurchaseOrder tbl where tbl.customer.id = :customerId")
    Double getTotalAmountForCustomer(@Param("customerId") Long customerId);

	@Query("SELECT COUNT(o) FROM PurchaseOrder o WHERE o.customer.customerCreditScore BETWEEN 501 AND 750")
    Long countOrdersForEligibleCustomers();

}
