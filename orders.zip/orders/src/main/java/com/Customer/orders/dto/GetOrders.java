package com.Customer.orders.dto;

import java.util.Date;

public class GetOrders {

	private Long orderId;
	private int quantity;
	private Date orderDate;
	private Double totalOrderAmount;
	private Long customerId;
	private Long mobileId;
	public GetOrders() {
		super();
	}
	public GetOrders(Long orderId, int quantity, Date orderDate, Double totalOrderAmount, Long customerId,
			Long mobileId) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.orderDate = orderDate;
		this.totalOrderAmount = totalOrderAmount;
		this.customerId = customerId;
		this.mobileId = mobileId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Double getTotalOrderAmount() {
		return totalOrderAmount;
	}
	public void setTotalOrderAmount(Double totalOrderAmount) {
		this.totalOrderAmount = totalOrderAmount;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getMobileId() {
		return mobileId;
	}
	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "GetOrders [orderId=" + orderId + ", quantity=" + quantity + ", orderDate=" + orderDate
				+ ", totalOrderAmount=" + totalOrderAmount + ", customerId=" + customerId + ", mobileId=" + mobileId
				+ "]";
	}
	
	
}
