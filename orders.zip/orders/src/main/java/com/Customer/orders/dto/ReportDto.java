package com.Customer.orders.dto;

import java.util.Date;

public class ReportDto {

	private Long reportId;

    private Date date;

    private double totalAmountNonEligible;

    private long totalRequestsEligibleCustomers;

	public ReportDto(Long reportId, Date date, double totalAmountNonEligible, long totalRequestsEligibleCustomers) {
		super();
		this.reportId = reportId;
		this.date = date;
		this.totalAmountNonEligible = totalAmountNonEligible;
		this.totalRequestsEligibleCustomers = totalRequestsEligibleCustomers;
	}

	public ReportDto() {
		super();
	}

	public Long getReportId() {
		return reportId;
	}

	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getTotalAmountNonEligible() {
		return totalAmountNonEligible;
	}

	public void setTotalAmountNonEligible(double totalAmountNonEligible) {
		this.totalAmountNonEligible = totalAmountNonEligible;
	}

	public long getTotalRequestsEligibleCustomers() {
		return totalRequestsEligibleCustomers;
	}

	public void setTotalRequestsEligibleCustomers(long totalRequestsEligibleCustomers) {
		this.totalRequestsEligibleCustomers = totalRequestsEligibleCustomers;
	}

	@Override
	public String toString() {
		return "ReportDto [reportId=" + reportId + ", date=" + date + ", totalAmountNonEligible="
				+ totalAmountNonEligible + ", totalRequestsEligibleCustomers=" + totalRequestsEligibleCustomers + "]";
	}
    
}
