package com.Customer.orders.dto;

public class ResponseDto {

	
	private Long id;
	private String statusMsg;

    public ResponseDto() {
    }

    public ResponseDto(Long id,String statusMsg) {
    	 this.id=id;
        this.statusMsg = statusMsg;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "ResponseDto [id=" + id + ", statusMsg=" + statusMsg + "]";
	}

}
