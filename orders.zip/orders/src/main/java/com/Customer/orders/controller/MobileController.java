package com.Customer.orders.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Customer.orders.dto.GetAllMobile;
import com.Customer.orders.dto.MobileCrtDto;
import com.Customer.orders.dto.MobileUpdateDto;
import com.Customer.orders.dto.ResponseDto;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.Mobile;
import com.Customer.orders.service.CustomerService;
import com.Customer.orders.service.MobileService;

@RestController
@RequestMapping("mobiles/")
public class MobileController {

	public static final Logger logger = LogManager.getLogger(MobileController.class);

	@Autowired
	MobileService mobileService;
	
	@Autowired
	CustomerService customerService;

	@PostMapping(path = "addmobiles", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> saveMobile(@RequestBody MobileCrtDto mobileDto) {
		ResponseDto response = null;
		try {
			logger.info("{} >> mobileDto:[{}],", mobileDto);
			Long id = mobileService.saveMobiles(mobileDto);
			if (id > 0) {
				response = new ResponseDto(id, "Mobile Created Successfully");
				logger.info("{} <<:saveMobile:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Mobile Created failed");
				logger.info("{} <<:saveMobile:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			logger.error("Error saving Mobile", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(path = "getAllMobiles", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<GetAllMobile>> getAllMobiles() {
		try {
			List<GetAllMobile> response = mobileService.getAllMobiles();
			logger.info("{} <<:getAllMobiles:Response:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
		}
	}

	@GetMapping(path = "/getById/{mobileId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<GetAllMobile> getMobilesById(@PathVariable("mobileId") Long mobileId) {
        try {
        	GetAllMobile response = mobileService.getByMobileId(mobileId);
            if (response != null) {
                logger.info(">>getMobilesById:[{}]", response);
                return ResponseEntity.status(HttpStatus.OK).body(response);
            } else {
                logger.info("{} <<:getMobilesById:Response:{}", response);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

	@PutMapping(path = "updatemobile/{mobileId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> updateMobile(@RequestBody MobileUpdateDto updateDto) {
		ResponseDto response = null;
		try {
			long id = mobileService.updateMobiles(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "Mobile update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Mobile update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}

	@DeleteMapping(path = "deletemobiles/{mobileId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deleteMobile(@PathVariable("mobileId") Long mobileId) {
		ResponseDto response = null;
		try {
			long id = mobileService.deleteMobileById(mobileId);
			if (id > 0) {
				response = new ResponseDto(id, "Mobile deleted Successfully");
				logger.info("{} <<:deleteMobile:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Mobile fail to delete");
				logger.info("{} <<:deleteMobile:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
}
