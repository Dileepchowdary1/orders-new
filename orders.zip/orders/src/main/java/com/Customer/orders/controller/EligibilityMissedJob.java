package com.Customer.orders.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.Customer.orders.entity.Customers;
import com.Customer.orders.repository.CustomerRepo;

@Component
public class EligibilityMissedJob {

	public static final Logger logger = LogManager.getLogger(EligibilityMissedJob.class);
	@Autowired
	private CustomerRepo customerRepository;

	@Scheduled(cron = "0 0 0 * * ?") // Run every day at midnight
	public void findCustomersWithMissedEligibility() {
		try {
			List<Customers> customersWithMissedEligibility = customerRepository.findCustomersWithMissedEligibility();
			for (Customers customer : customersWithMissedEligibility) {
				logger.info("Customer {} missed phone eligibility by 50 credit scores.", customer.getCustomerName());
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error occurred while processing eligibility check job", e);
		}
	}
}
