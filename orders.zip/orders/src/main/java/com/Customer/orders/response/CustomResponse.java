package com.Customer.orders.response;

public class CustomResponse extends Response{
	
	private String id;
    private Long childId;

    public CustomResponse(boolean status, String messages) {
        super(status, messages);
    }

    public CustomResponse(boolean status, String messages, String id) {
        super(status, messages);
        this.id = id;
    }
    

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getChildId() {
		return childId;
	}

	public void setChildId(Long childId) {
		this.childId = childId;
	}

	@Override
    public String toString() {
        return "CustomResponse{"+super.toString() + "id=" + id + ", childId=" + childId + '}';
    }

}
