package com.Customer.orders.dto;

public class MobileCrtDto {
	
	private String mobileName;
	private Double mobilePrice;
	 private Long customerId;
	 private Integer stockQuantity;
	public MobileCrtDto() {
		super();
	}
	public MobileCrtDto( String mobileName, Double mobilePrice,Long customerId,Integer stockQuantity) {
		super();
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
		this.customerId=customerId;
		this.stockQuantity=stockQuantity;
	}
	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public Double getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(Double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	public Integer getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(Integer stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	@Override
	public String toString() {
		return "MobileCrtDto [mobileName=" + mobileName + ", mobilePrice=" + mobilePrice + ", customerId=" + customerId
				+ ", stockQuantity=" + stockQuantity + "]";
	}
	

}
