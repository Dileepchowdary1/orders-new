package com.Customer.orders.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Customer.orders.dto.CustomerCrtDto;
import com.Customer.orders.dto.CustomerUpdateDto;
import com.Customer.orders.dto.GetAllCustomers;
import com.Customer.orders.dto.ResponseDto;
import com.Customer.orders.service.CustomerService;

@RestController
@RequestMapping("OrderCustomers/")
public class CustomerController {

	public static final Logger logger = LogManager.getLogger(CustomerController.class);

	@Autowired
	CustomerService customerService;

	@PostMapping(path = "createCustomers", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> saveCustomer(@RequestBody CustomerCrtDto customerDto) {
		ResponseDto response = null;
		try {
			long id = customerService.saveCustomer(customerDto);
			if (id > 0) {
				response = new ResponseDto(id, "Customer Created Successfully");
				logger.info("{} <<:saveCustomer:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Customer Created failed");
				logger.info("{} <<:saveCustomer:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error saving customer", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(path = "getallcustomers", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<GetAllCustomers>> getAllCustomers() {
		try {
			List<GetAllCustomers> response = customerService.getAllCustomers();
			logger.info("{} <<:getAllCustomers:Response:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
		}
	}

	@GetMapping(value = "/fetchcustomer/{customerId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> fetchCustomersById(@PathVariable("customerId") Long customerId) {
		ResponseDto response = null;
		try {
			String message = customerService.fetchCustomerById(customerId);
			response = new ResponseDto(customerId, message);
			logger.info("fetchCustomersById:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto());
		}
	}

	@PutMapping(path = "updatecustomer/{customerId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> updateCustomer(@RequestBody CustomerUpdateDto updateDto) {
		ResponseDto response = null;
		try {
			long id = customerService.updateCustomers(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "Customer update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Customer update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}

	@DeleteMapping(path = "deletecustomer/{customerId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deleteCustomer(@PathVariable("customerId") Long customerId) {
		ResponseDto response = null;
		try {
			long id = customerService.deleteCustomerById(customerId);
			if (id > 0) {
				response = new ResponseDto(id, "Customer deleted Successfully");
				logger.info("{} <<:deleteCustomer:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Customer fail to delete");
				logger.info("{} <<:deleteCustomer:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}

}
