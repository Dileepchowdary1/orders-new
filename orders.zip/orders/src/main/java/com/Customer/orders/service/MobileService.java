package com.Customer.orders.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Customer.orders.dto.GetAllMobile;
import com.Customer.orders.dto.MobileCrtDto;
import com.Customer.orders.dto.MobileUpdateDto;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.entity.Mobile;
import com.Customer.orders.mapper.Mapper;
import com.Customer.orders.repository.CustomerRepo;
import com.Customer.orders.repository.MobileRepo;

@Service
public class MobileService {

	public static final Logger logger = LogManager.getLogger(MobileService.class);

	@Autowired
	MobileRepo mobileRepository;

	@Autowired
	CustomerRepo customerRepository;

	public long saveMobiles(MobileCrtDto dto) {
		try {
			logger.info("{} >> saveMobiles:[{}],", dto);
			Mobile mobile = new Mobile();
			mobile.setMobileName(dto.getMobileName());
			mobile.setMobilePrice(dto.getMobilePrice());
			mobile.setStockQuantity(dto.getStockQuantity());
			if (dto.getCustomerId() != null) {
				Customers customer = new Customers();
				customer.setCustomerId(dto.getCustomerId());
				mobile.setCustomer(customer);
			}
			Mobile mobileResposne = mobileRepository.save(mobile);
			logger.info("{} >> mobileResposne:[{}],", mobileResposne);
			return mobileResposne.getMobileId();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public List<GetAllMobile> getAllMobiles() {
		try {
			List<Object[]> mobile = mobileRepository.findAllMobiles();
			List<GetAllMobile> response = mobile.stream().map(mobileData -> {
				Long mobileId = (Long) mobileData[0];
				String custname = (String) mobileData[1];
				Double price = (Double) mobileData[2];
				Long customerId = (Long) mobileData[3];
				int quality = (int) mobileData[4];
				return new GetAllMobile(mobileId, custname, price, customerId, quality);
			}).collect(Collectors.toList());
			logger.info("{} <<:getAllMobiles:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public long deleteMobileById(Long mobileId) {
		try {
			logger.info("{} >> deleteMobileById:[{}],", mobileId);
			mobileRepository.deleteById(mobileId);
			return mobileId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public long updateMobiles(MobileUpdateDto updateDto) {
		Mobile mobile = null;
		try {
			if (updateDto.getMobileId() != null && updateDto.getMobileId() > 0) {
				mobile = mobileRepository.getMobilesBymobileId(updateDto.getMobileId());
				if (mobile != null) {
					Customers customer = customerRepository.getOne(updateDto.getCustomerId());
					 if (customer == null) {
		                    throw new EntityNotFoundException("Customer not found with ID: " + updateDto.getCustomerId());
		                }
					Mobile mobileDto = Mapper.INSTANCE.updateDtoToMobile(updateDto);
					mobileDto.setCustomer(customer);
					logger.info("{}<<:updateMobiles:[{}]", mobileDto);
					mobileDto = mobileRepository.saveAndFlush(mobileDto);
					return mobileDto.getMobileId();
				}
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public GetAllMobile getByMobileId(Long mobileId) {
		try {
			Mobile response = mobileRepository.getMobilesBymobileId(mobileId);
			if (response.getCustomer() != null) {
				GetAllMobile dto = new GetAllMobile(response.getMobileId(), response.getMobileName(),
						response.getMobilePrice(), response.getCustomer().getCustomerId(), response.getStockQuantity());
				logger.info("{} <<:getByMobileId:Response:{}", dto);
				return dto;
			} else {
				logger.info("Customer is null for MobileId: {}", mobileId);
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return null;
		}
	}

}
